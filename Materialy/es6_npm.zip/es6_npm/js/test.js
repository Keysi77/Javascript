'use strict';

console.log('hej');