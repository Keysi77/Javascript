var dudes = document.querySelectorAll('.choice img');
	dudes = Array.prototype.slice.call(dudes);  // Array.from( dudes );


dudes.forEach(function( dude ) {

	// show score form localStorage
	updateDude(dude);


	// on click, increase score
	dude.addEventListener('click', function() {
		increaseScore(dude);
	});


	// mouse enters, enemy hurts
	dude.addEventListener('mouseover', function() {
		var otherDude = _.without( dudes, this )[0];
		otherDude.classList.add('desaturate');
	});


	// mouse leaves, enemy rises
	dude.addEventListener('mouseout', function() {
		var otherDude = _.without( dudes, this )[0];
		otherDude.classList.remove('desaturate');
	});

});


// ---------------


/**
 * vasho -> scoreVasho
 *
 * @param  {HTMLImageElement} dude
 * @return {string}      	  localStorage key
 */
function getKeyFrom( dude ) {
	return 'score' + _.capitalize( dude.alt );
}



/**
 * get scoreVasho from localStorage
 *
 * @param  {HTMLImageElement} dude
 * @return {number}
 */
function getScore( dude ) {
	return +localStorage.getItem( getKeyFrom(dude) ) || 0;
}


/**
 * set scoreVasho to localStorage
 *
 * @param {HTMLImageElement}  dude   dom element
 * @param {number} 			  score  score number
 */
function setScore( dude, score ) {
	localStorage.setItem( getKeyFrom(dude), score);
}


/**
 * update dudes DOM element
 *
 * @param  {HTMLImageElement} dude
 */
function updateDude( dude ) {
	var score = getScore(dude);
	dude.nextElementSibling.textContent = score;
}


/**
 * increase score for dude
 * both dom and localStorage
 *
 * @param  {HTMLImageElement}  dude
 */
function increaseScore( dude ) {
	var score = getScore(dude);
	score++;

	setScore(dude, score);
	updateDude(dude);
}
