import _ from "lodash"


export default class Form {

	// grab elements
	constructor() {
		this.el = document.querySelector('.add-new')

		this.inputs = {
			who: document.querySelector('input[name=who]'),
			wat: document.querySelector('input[name=wat]')
		}
	}


	// reset form
	reset() {
		_.forIn( this.inputs, input => input.value = '' ) // clear value of inputs
		this.inputs.who.focus() // focus on 'who'
	}


	// get input values
	get who() {
		return _.trim( this.inputs.who.value ) || false
	}

	get wat() {
		return _.trim( this.inputs.wat.value ) || false
	}

}