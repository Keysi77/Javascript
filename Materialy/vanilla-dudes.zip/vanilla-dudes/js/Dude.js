import _ from "lodash"


export default class Dude {

	constructor( list, form ) {
		this.list = list
		this.form = form

		this._who = ''
		this._wat = ''
	}


	// add new dude
	addNew() {
		// this.createNewNode() && this.form.reset()

		if ( this.createNewNode() ) {
			this.form.reset()
		}
	}


	// get last index
	getLastIndex() {
		let lastDude = _.last( this.list.children )
		return lastDude ? +lastDude.dataset.index : 0
	}


	// new id
	getNextIndex() {
		return this.getLastIndex() + 1
	}


	// create HTML for new dude
	createNewHTML() {
		return `

			<li class="dude" data-index="${this.getNextIndex()}">
				<a class="ctrl remove">x</a>
				<article>
					${this._who}
					<span>${this._wat}</span>
				</article>
			</li>

		`.trim()
	}


	// add new LI to DOM
	createNewNode( who = this.form.who, wat = this.form.wat ) {
		this._who = who
		this._wat = wat

		if ( this.validate() ) {
			let html = this.createNewHTML()
			this.list.insertAdjacentHTML( 'beforeend', html )
			return true
		}
	}


	// all values?
	validate() {
		return this._who && this._wat
	}


	// remove dude & dom node
	remove( node ) {
		node.remove()  // dom node
	}

}