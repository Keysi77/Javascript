import '../scss/base.scss'

import axios from "axios"
import Form  from "./Form.js"
import Dude  from "./Dude.js"

const form = new Form()
const list = document.querySelector('.dude-list')
const dude = new Dude( list, form )



/**
 * LOAD SHIT FROM JSON
 */
axios.get('http://api.myjson.com/bins/zg7ze')
	.then( res => {
		res.data.forEach(character => {

			let { who, wat } = character
			dude.createNewNode( who, wat )

		})
	})



/**
 * ADD NEW
 */
form.el.addEventListener('keyup', event => {
	if ( event.code === 'Enter' ) {
		event.preventDefault()
		dude.addNew()
	}
})



/**
 * REMOVE
 */
list.addEventListener('click', event => {  // event delegation
	if ( event.target.classList.contains('remove') ) { // clicked on 'remove' link
		dude.remove( event.target.parentNode )
	}
})