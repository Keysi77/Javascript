import Mario, { doMath, theGoodNumber } from "./math.js";

Mario.jump();
console.log(theGoodNumber);