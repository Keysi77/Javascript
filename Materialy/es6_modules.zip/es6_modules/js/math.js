const pod = "U Talkin' U2 To Me?";


export let theGoodNumber = 69;

export function doMath( ...rest ) {
	return rest.reduce( (sum, val) => sum + val )
}

export default class Mario {
	static jump() {
		console.log('jumpa!');
	}
}