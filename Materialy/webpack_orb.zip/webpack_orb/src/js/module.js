export function hi(name) {
	alert(`hi ${name}`)
}

export function firstName() {
	console.log( 'Tomáš' );
}

export function lastName() {
	console.log( 'Maštalír' );
}