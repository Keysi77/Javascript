//images
import Happy from '../img/happy.png'


// stylesheets
import '../sass/base.scss'


// javascript
import { lastName } from './module'
import './orb'

lastName()