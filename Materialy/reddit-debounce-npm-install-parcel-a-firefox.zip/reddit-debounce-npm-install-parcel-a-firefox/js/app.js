/**
 * - NAJPRV npm install
 * - POTOM parcel index.html
 * - POTOM firefox
 */

import _ from "lodash";
import axios from "axios";


// input kam pises
const input = document.querySelector('input[type=search]');


// po tuknuti pockaj pol sekundy
input.addEventListener('keyup', _.debounce( () => {

	// potom odpal ziadost na reddit
	axios.get('https://www.reddit.com/r/BoJackHorseman.json', { crossdomain: true })
		.then(res => {

			let posts = res.data.data.children;

			// z kadeho chceme len nadpis a link
			posts.forEach(post => {
				let { title, url } = post.data;

				let link = _.trim(`
					<a href="${url}">${title}</a>
				`);

				console.log( link );
			});

		});

}, 500 ));


/*

// NO DEBUNCE verzia
input.addEventListener('keyup', event => {
	 axios.get('https://www.reddit.com/r/BoJackHorseman.json', { crossdomain: true })
		.then( res => {
			console.log( res.data.data.children );
		});
});

*/

