'use strict';


/**
 * PROGRESS BAR
 */
const progressBar = document.querySelector('progress');

let max = document.body.scrollHeight - window.innerHeight,
	debounceTimer = null,
	scheduled = false;

progressBar.max = max;

// debounce
addEventListener('scroll', () => {
	progressBar.value = pageYOffset;

	clearTimeout(debounceTimer);
	debounceTimer = setTimeout(() => {
		console.log( 'position stored in db' );
	}, 1000);
});

// resize, recalculate max
addEventListener('resize', () => {
	progressBar.max = document.body.scrollHeight - window.innerHeight;
});