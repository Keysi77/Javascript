import '../scss/base.scss';


/**
 * YABLKO START
 */


	[ 1, 2, 3 ].map( n => n + 69 );


/**
 * YABLKO END
 */