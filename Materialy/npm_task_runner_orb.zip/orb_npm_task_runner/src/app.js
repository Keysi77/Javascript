/**
 * I AM ABSOLUTELY ES6+
 */
class SayHelloCreep {
	constructor(name) {
		console.log(`hello ${name}`);
	}
}
let what = new SayHelloCreep(`Tomino Mašt.`);



/**
 * GRAB ELEMENTS
 */
const progress = document.querySelector('.progress');
const textarea = document.querySelector('textarea');
const counter  = document.querySelector('.counter');


/**
 * SET DASH-ARRAY/OFFSET
 */
let pathLength = progress.getAttribute('r') * 2 * Math.PI,
	tweetLength = 40,
	warningZone = Math.floor(tweetLength * (1 / 2)),
	dangerZone = Math.floor(tweetLength * (3 / 4));

progress.style.strokeDasharray = `${pathLength}px`;
progress.style.strokeDashoffset = `${pathLength}px`;


/**
 * ON INPUT
 */
textarea.addEventListener('input', event => { // keyup, keydown

	let len = textarea.value.length,
		per = len / tweetLength;

	// handle progress
	if (len <= tweetLength) {
		let newOffset = pathLength - (pathLength * per) + 'px';
		progress.style.strokeDashoffset = newOffset;

		// handle colors
		progress.classList.toggle('warn', len > warningZone && len < dangerZone);
		progress.classList.toggle('danger', len >= dangerZone);
		progress.classList.toggle('tragedy', len == tweetLength);
	}

	// handle counter
	counter.textContent = tweetLength - len;
	counter.classList.toggle('danger', len >= tweetLength);

});